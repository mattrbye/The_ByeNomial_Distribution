---
date: 2023-12-01T00:00:00+01:00
draft: false
title: "Job #2"
jobTitle: "Chief Intern"
company: "Internet Affairs Inc. "
location: "Stavanger, Norway"
duration: "2023-2024"

---
### Fixing the world, one byte at a time

Continuing the quest. 