---
date: 2024-12-01T00:00:00+01:00
draft: false
title: "Job #3"
jobTitle: "CIO"
company: "Internet Affairs Inc. "
location: "Stavanger, Norway"
duration: "2024-now"

---
### Fixing the world, one byte at a time

Hostile takeover - who is the boss now!