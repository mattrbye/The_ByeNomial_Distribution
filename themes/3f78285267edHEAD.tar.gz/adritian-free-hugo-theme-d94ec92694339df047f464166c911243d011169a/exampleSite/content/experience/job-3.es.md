---
date: 2024-12-01T00:00:00+01:00
draft: false
title: "Puesto #3"
jobTitle: "Gerente General"
company: "Translated Content"
location: "Stavanger, Norway"
duration: "2024-now"

---
### Fixing the world, one byte at a time

Hostile takeover - who is the boss now!