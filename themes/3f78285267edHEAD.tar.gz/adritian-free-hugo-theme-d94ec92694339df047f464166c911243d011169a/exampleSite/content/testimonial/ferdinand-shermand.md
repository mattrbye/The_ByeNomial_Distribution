---
date: '2024-11-25T21:30:46+01:00' # date in which the content is created - defaults to "today"
title: 'Ferdinand Shermand'
draft: false # set to "true" if you want to hide the content 

name: "Ferdinand Shermand" # place/city/country for the experience. Fill-in.
position: "Butterfly collector" # from-to, for example "2022-2024". Fill-in.

params:
    image:
        x: "images/testimonials/testimonial3.png" # example: "images/clients/asgardia.png"
        _2x: "images/testimonials/testimonial3@2x.png" # example: "images/clients/asgardia@2x.png"

## For the content, you can use markdown
##
---

Working with this colleague has been an absolute pleasure. Their dedication, professionalism, and positive attitude make them an invaluable asset to our team. They consistently go above and beyond to ensure that projects are completed on time and to the highest standard. Their ability to collaborate effectively and support their colleagues is truly commendable. I am continually impressed by their innovative thinking and problem-solving skills. This colleague is not just a team member but a true inspiration and a driving force behind our team’s success.