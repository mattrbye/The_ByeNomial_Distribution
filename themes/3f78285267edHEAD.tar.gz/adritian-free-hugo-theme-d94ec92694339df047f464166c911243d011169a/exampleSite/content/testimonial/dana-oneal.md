---
date: '2024-11-25T21:50:45+01:00' # date in which the content is created - defaults to "today"
title: 'Dana Oneal'
draft: false # set to "true" if you want to hide the content 

name: "International Interrogations" # place/city/country for the experience. Fill-in.
position: "Internal Intern" # from-to, for example "2022-2024". Fill-in.

params:
    image:
        x: "images/testimonials/testimonial2.png" # example: "images/clients/asgardia.png"
        _2x: "images/testimonials/testimonial2@2x.png" # example: "images/clients/asgardia@2x.png"

## For the content, you can use markdown
##
---

I had the pleasure of working with this freelancer on several projects, and their performance has been nothing short of outstanding. They bring a high level of expertise, creativity, and dedication to every task. Their ability to understand project requirements and deliver exceptional results on time is truly impressive. They are a reliable and proactive professional who consistently exceeds expectations. I highly recommend this freelancer to anyone seeking top-notch skills and a collaborative partner.