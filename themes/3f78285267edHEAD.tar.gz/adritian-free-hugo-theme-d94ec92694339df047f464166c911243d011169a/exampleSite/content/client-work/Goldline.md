---
date: '2024-08-25T10:21:48+02:00' # date in which the content is created - defaults to "today"
title: 'Goldline'
draft: false # set to "true" if you want to hide the content 

link: "https://www.adrianmoreno.info" # optional URL to link the logo to

params:
    logo:
        x: "images/clients/goldline.png"
        _2x: "images/clients/goldline@2x.png"
## The content is not used (yet). If you have ideas on how to use it, 
## you can suggest it at https://github.com/zetxek/adritian-free-hugo-theme/discussions 
---
